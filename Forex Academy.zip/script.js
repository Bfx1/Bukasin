// Toggle password visibility
function togglePassword(fieldId) {
  const field = document.getElementById(fieldId);
  field.type = field.type === "password" ? "text" : "password";
}

// Registration form logic (unchanged from before)
document.addEventListener("DOMContentLoaded", () => {
  const registrationForm = document.getElementById("registrationForm");

  if (registrationForm) {
    registrationForm.addEventListener("submit", (e) => {
      e.preventDefault();

      const firstname = document.getElementById("firstname").value.trim();
      const lastname = document.getElementById("lastname").value.trim();
      const email = document.getElementById("email").value.trim();
      const username = document.getElementById("username").value.trim();
      const password = document.getElementById("password").value;
      const confirmPassword = document.getElementById("confirm_password").value;
      const gender = document.querySelector('input[name="gender"]:checked')?.value;
      const dob = document.getElementById("dob").value;
      const phone = document.getElementById("phone").value.trim();
      const country = document.getElementById("country").value;
      const terms = document.getElementById("terms").checked;

      if (!firstname || !lastname || !email || !username || !password || !confirmPassword || !gender || !dob || !phone || !country) {
        alert("Please fill in all fields.");
        return;
      }

      if (password !== confirmPassword) {
        alert("Passwords do not match.");
        return;
      }

      if (!terms) {
        alert("You must agree to the terms and conditions.");
        return;
      }

      // Age check
      const birthDate = new Date(dob);
      let age = new Date().getFullYear() - birthDate.getFullYear();
      const monthDiff = new Date().getMonth() - birthDate.getMonth();
      if (monthDiff < 0 || (monthDiff === 0 && new Date().getDate() < birthDate.getDate())) {
        age--;
      }
      if (age < 18) {
        alert("You must be at least 18 years old to register.");
        return;
      }

      const users = JSON.parse(localStorage.getItem("users")) || [];
      const duplicate = users.find(u => u.username === username || u.email === email);
      if (duplicate) {
        alert("Username or Email already exists.");
        return;
      }

      const newUser = { firstname, lastname, email, username, password, gender, dob, phone, country };
      users.push(newUser);
      localStorage.setItem("users", JSON.stringify(users));

      alert("Registration successful! Redirecting to login...");
      window.location.href = "login.html";
    });
  }

  // Login form logic
  const loginForm = document.getElementById("loginForm");

  if (loginForm) {
    loginForm.addEventListener("submit", (e) => {
      e.preventDefault();

      const identifier = document.getElementById("login_identifier").value.trim();
      const password = document.getElementById("login_password").value;

      const users = JSON.parse(localStorage.getItem("users")) || [];
      const user = users.find(u =>
        (u.username === identifier || u.email === identifier) && u.password === password
      );

      if (user) {
        // Save current user session
        localStorage.setItem("currentUser", JSON.stringify(user));

        alert("Login successful! Redirecting to dashboard...");
        window.location.href = "dashboard.html";
      } else {
        alert("Invalid username/email or password.");
      }
    });
  }
});

// Forgot password logic
function forgotPassword() {
  const identifier = prompt("Enter your username or email to reset password:");
  if (!identifier) return;

  const users = JSON.parse(localStorage.getItem("users")) || [];
  const userIndex = users.findIndex(u => u.username === identifier || u.email === identifier);

  if (userIndex === -1) {
    alert("No account found with that username/email.");
    return;
  }

  const newPassword = prompt("Enter your new password:");
  if (!newPassword) return;

  users[userIndex].password = newPassword;
  localStorage.setItem("users", JSON.stringify(users));

  alert("Password reset successful! You can now log in with your new password.");
}
// Mobile menu toggle
document.addEventListener("DOMContentLoaded", () => {
  const menuToggle = document.querySelector(".menu-toggle");
  const navLinks = document.querySelector(".nav-links");

  if (menuToggle && navLinks) {
    menuToggle.addEventListener("click", () => {
      navLinks.classList.toggle("active");
    });
  }

  // Show/Hide Logout depending on login state
  const logoutLink = document.getElementById("logoutLink");
  const loginLink = document.getElementById("loginLink");
  const registerLink = document.getElementById("registerLink");
  const currentUser = JSON.parse(localStorage.getItem("currentUser"));

  if (currentUser) {
    logoutLink.style.display = "inline-block";
    loginLink.style.display = "none";
    registerLink.style.display = "none";
  } else {
    logoutLink.style.display = "none";
  }
});

// Logout with confirmation
function logout() {
  const confirmLogout = confirm("Are you sure you want to log out?");
  if (confirmLogout) {
    localStorage.removeItem("currentUser");
    alert("You have been logged out.");
    window.location.href = "login.html";
  }
}
// Update progress bar when returning to dashboard
document.addEventListener("DOMContentLoaded", () => {
  const forexProgress = localStorage.getItem("progress-forex") || 0;
  document.getElementById("progress-forex").style.width = forexProgress + "%";
});

// Function to mark a lesson complete
function markProgress(courseKey) {
  localStorage.setItem("progress-" + courseKey, 100);
  alert(courseKey + " marked as complete!");
}

// Update progress bar when returning to Forex Basics page
document.addEventListener("DOMContentLoaded", () => {
  const forexProgress = localStorage.getItem("progress-forex") || 0;
  document.getElementById("progress-forex").style.width = forexProgress + "%";
});

// Function to mark lesson progress
function markLesson(courseKey, progressValue) {
  localStorage.setItem("progress-" + courseKey, progressValue);
  document.getElementById("progress-" + courseKey).style.width = progressValue + "%";
  alert("Progress updated: " + progressValue + "% complete!");
}

document.addEventListener("DOMContentLoaded", () => {
  const forexProgress = localStorage.getItem("progress-forex") || 0;
  document.getElementById("progress-forex").style.width = forexProgress + "%";
});

function markLesson(courseKey, progressValue) {
  localStorage.setItem("progress-" + courseKey, progressValue);
  document.getElementById("progress-" + courseKey).style.width = progressValue + "%";
  alert("Progress updated: " + progressValue + "% complete!");
}